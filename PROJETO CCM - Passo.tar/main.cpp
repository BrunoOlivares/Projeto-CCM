#include "mbed.h"
#include <cstdint>
#include <string.h>
#include <Serial.h>
#include <SerialBase.h>

// Serial

    Serial MotorPasso(USBTX, USBRX); // Definição da Serial via USB

// GPIO

   DigitalOut EN_A (D2); // Habilitação do Braço A da Ponte H
   DigitalOut EN_B (A4); // Habilitação do Braço B da Ponte H
   BusOut Mov(D5, A0, D4, A1); // Chaveamento dos braços da Ponte H

// Variáveis de apoio

    int lista[4] = {0b1100, 0b0110, 0b0011, 0b1001}; // Lista de ativação dos braços do X-NUCLEO-IHM04A1

    int passo = 0; // Variável de controle de ciclo de passo do motor

    bool controle = 0; // Variável de controle de funcionamento manual do sistema
    int automatico = 0; // Variável de controle de funcionamento automatico do sistema
    int horario = 1; // Variável de controle de rotação horária do motor em modo manual
    int antihorario = 0; // Variável de controle de rotação antihorária do motor em modo manual

    int velocidade = 0; // Variável de controle de velocidade de rotação do motor em modo manual

    char Comandos [64]; // Variável de recebimento de comandos via Serial
    int index = 0; // Variável de controle de leitura da serial
    char caracter; // Variável de recebimento de caracter provindo da serial

    int qpassos; // Variável de controle da quantidade de passos a serem dadas pelo motor em modo automático integrado ao sentido de rotação
    float qpasso_abs; // Variável que identifica a quantidade de passos absolutos a serem dados do motor

    float passosatual = 0; // Controle da quantidade de passos dentro do ciclo de execução automático

// Função para recebimento e reconstrução de comandos provindosda Serial 

    void Callback1() {

        // Recebimento do primeiro caracter disponível na Serial

            caracter = MotorPasso.getc();

        // Loop de recebimento de caracteres até encontrar o terminador
        
            while (caracter != '\n') {

                // Adicionar o caracter obtido à variável Comandos

                    Comandos[index] = caracter;

                // Aumentar o index onde o próximo caracter há de ser colocado no char array

                    index++;

                // Recebimento do próximo caracter disponível na Serial
                    
                    caracter = MotorPasso.getc();

            } 

        // Definição do último caracter da variável comandos como sendo nulo

            Comandos[index+1] = '\0';

        // Zeramento da variável index

            index = 0;

    }

// Função de Limpeza da variável "Comandos"

    void Limpa() {

        // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

            while (index < sizeof(Comandos)) {

                // Colocação da palavra "nula" em cada caracter do char array

                    Comandos[index] = '\0';

                    index++;

            }

            index = 0;

    }

// Função referente ao modo manual de funcionamento

void Manual() {

    // Ativação dos braços da ponte H

        EN_A = 1;
        EN_B = 1;

    // Ativação da rotação horária do motor caso a palavra "Horario" seja recebida na Serial

        if (strcmp(Comandos, "Horario") == 0){

            // Desativação do sentido antihorário e habilitação do sentido horário

                antihorario = 0;
                horario = 1;

            // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

                Limpa();

        }

    // Ativação da rotação horária do motor caso a palavra "Horario" seja recebida na Serial

        if (strcmp(Comandos, "AntiHorario") == 0) {

            horario = 0;
            antihorario = 1;

            Limpa();

        }

    // Quando a quantidade de passo no ciclo é maior que 4, a variável passo é resetada

        if (passo == 4) {

            passo = 0;

        }

    // Quando o sentido selecionado é o horário, a lista de sentido é lida da esquerda para a direita

        if (antihorario == 1) {

            Mov = lista[passo];

        }

    // Quando o sentido selecionado é o antihorário, a lista de sentido é lida da direita para a esquerda

        if (horario == 1) {

            Mov = lista[3 - passo];

        }

    // Caso o comando recebido na Serial seja um número, o mesmo é colocado na variável velocidade

        if(atoi(Comandos) != 0) {

            velocidade = atoi(Comandos);
            
        }

    // O tempo entre ciclos é definido conforme a velocidade definida no modo
    
        wait_us(5000 - 35 * velocidade);

    // Ao final de cada ciclo, a variável passo é aumentada em uma unidade

        passo++; 

}

// Função referente ao modo automatico de funcionamento

void Automatico() {

    // Zeramento da variável de passos para evitar ruido 

        passo = 0;

    // Caso seja identificado um numero dentro da serial, o mesmo é convertido para um valor numérico a ser guardado na variável "qpassos"

        if(atoi(Comandos) != 0) {

            qpassos = atoi(Comandos);

            // Limpeza da variável Comandos

                Limpa();

        }

    // Caso o sinal da variável "qpassos" seja negativo, o valor em módulo é guardado na variável "qpasso_abs"

        if (qpassos < 0) {

            qpasso_abs = -qpassos;

        }

    // Caso contrário, o valor da variável é colocado inteiramente na outra, sem alterações

        else {

            qpasso_abs = qpassos;

        }

    // Caso seja executado a rotina automática do motor

        if (strcmp(Comandos, "Executar") == 0) {

            // Habilitação dos braços da ponte H

                EN_A = 1;
                EN_B = 1;

            // Limpeza da variável Comandos

                Limpa();

            // Enquanto a quantidade de passos desejada não for alcançada

                while (passosatual <= qpasso_abs){

                    // Quando a quantidade de passo no ciclo é maior que 4, a variável passo é resetada

                        if (passo == 4) {

                            passo = 0;

                        }

                    // Quando o sentido selecionado é o horário, a lista de sentido é lida da esquerda para a direita

                        if (qpassos < 0) {

                            Mov = lista[passo];

                        }

                    // Quando o sentido selecionado é o antihorário, a lista de sentido é lida da direita para a esquerda

                        if (qpassos >= 0) {

                            Mov = lista[3 - passo];

                        }
                    
                    // O tempo entre ciclos é definido e fixo
                    
                        wait_us(2500);

                    // Ao final de cada ciclo, a variável passo é aumentada em uma unidade

                        passo++; 
                        passosatual++;

                }

                // Zeramento da variável de todas as variáveis utilizadas para permitir novo comando

                    qpassos = 0;
                    passosatual = 0;
                    passo = 0;
                    qpasso_abs = 0;

                // Desligamento dos braços da ponte H
                
                    EN_A = 0;
                    EN_B = 0;

        }

}

// Função Principal

    int main() {

        // Atribuição da função Callback em caso de mudanças na Serial

            MotorPasso.attach(&Callback1);

        // Definição da velocidade de trasnmissão e recebimento de dados na Serial 

            MotorPasso.baud(115200);

        // Loop Principal

            while(1) {

                // Estado inicial das pontes H compo sendo desligadas

                    EN_A = 0;
                    EN_B = 0;
                    
                // Ativação do Modo Manual quando a palavra "Manual" seja recebida na Serial

                    if (strcmp(Comandos, "Manual") == 0) {

                        // Desligamento do Modo Automático e Comutação do modo Manual

                            automatico = 0;
                            controle = !controle;

                        // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

                        Limpa();

                    }

                // Ativação do modo Automático quando a palavra "Automatica" seja recebida no Serial

                    if (strcmp(Comandos, "Automatico") == 0){

                        // Desligamento do Modo Manual e comutação do modo Automático

                            controle = 0;
                            automatico = !automatico;

                        // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

                            Limpa();

                        // Desabilitação dos braços da ponte H

                            EN_A = 0;
                            EN_B = 0;

                    }

                // Funcionamento do sistema em estado Manual

                    if (controle == 1) {

                        // Ativação do modo Manual

                            Manual();

                    }

                // Funcionamento do sistema em estado Automático

                    if (automatico == 1) {

                        Automatico();

                    }

            }

    }



