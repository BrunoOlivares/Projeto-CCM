#include "mbed.h"
#include <cstdint>
#include <string.h>
#include <Serial.h>
#include <SerialBase.h>
#include <math.h>

// Serial

    Serial MotorCC(USBTX, USBRX); // Definição da Serial via USB

// GPIO

   PwmOut EN_A (D2); // Habilitação do Braço A da Ponte H
   DigitalOut IN_A (D5); // Chave A da ponte H
   DigitalOut IN_B (D4); // Chave B da ponte H

// Variáveis de apoio

    bool controle = 0; // Variável de controle de funcionamento manual do sistema
    int automatico = 0; // Variável de controle de funcionamento automatico do sistema
    int horario = 1; // Variável de controle de rotação horária do motor em modo manual
    int antihorario = 0; // Variável de controle de rotação antihorária do motor em modo manual

    float velocidade = 0; // Variável de controle de velocidade de rotação do motor em modo manual

    char Comandos [64]; // Variável de recebimento de comandos via Serial
    int index = 0; // Variável de controle de leitura da serial
    char caracter; // Variável de recebimento de caracter provindo da serial

    int qtempo; // Variável de controle da quantidade de tempo a ser acionado o motor em modo automático integrado ao sentido de rotação
    float qtempo_abs; // Variável que identifica a quantidade de tempo absoluto a serem dados do motor

// Função para recebimento e reconstrução de comandos provindos da Serial 

    void Callback1() {

        // Recebimento do primeiro caracter disponível na Serial

            caracter = MotorCC.getc();

        // Loop de recebimento de caracteres até encontrar o terminador
        
            while (caracter != '\n') {

                // Adicionar o caracter obtido à variável Comandos

                    Comandos[index] = caracter;

                // Aumentar o index onde o próximo caracter há de ser colocado no char array

                    index++;

                // Recebimento do próximo caracter disponível na Serial
                    
                    caracter = MotorCC.getc();

            } 

        // Definição do último caracter da variável comandos como sendo nulo

            Comandos[index+1] = '\0';

        // Zeramento da variável index

            index = 0;

    }

// Função de Limpeza da variável "Comandos"

    void Limpa() {

        // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

            while (index < sizeof(Comandos)) {

                // Colocação da palavra "nula" em cada caracter do char array

                    Comandos[index] = '\0';

                    index++;

            }

            index = 0;

    }

// Função de controle manual

    void Manual() {

        // Ativação dos braços da ponte H

            EN_A.write(0);
            IN_A = 1;
            IN_B = 0;

        // Ativação da rotação horária do motor caso a palavra "Horario" seja recebida na Serial

            if (strcmp(Comandos, "Horario") == 0){

                // Desativação do sentido antihorário e habilitação do sentido horário

                    antihorario = 0;
                    horario = 1;

                // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

                    Limpa();

            }

        // Ativação da rotação horária do motor caso a palavra "Horario" seja recebida na Serial

            if (strcmp(Comandos, "AntiHorario") == 0) {

                // Desativação do sentido horario e habilitação do sentido antihorário

                    horario = 0;
                    antihorario = 1;

                // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

                    Limpa();

            }

        // Quando o sentido selecionado é o antihorário, a Chave A é habilitada enquanto a B é desabilitada

            if (antihorario == 1) {

                IN_A = 1;
                IN_B = 0;

            }

        // Quando o sentido selecionado é o horário, a Chave A é desabilitada enquanto a B é habilitada

            if (horario == 1) {

                IN_A = 0;
                IN_B = 1;

            }

        // Caso o comando recebido na Serial seja um número, o mesmo é colocado na variável velocidade e o valor é aplicado na saída PWM

            if(atoi(Comandos) != 0) {

                velocidade = atoi(Comandos);

                EN_A.write(velocidade / 100);
                
            }

        // O tempo entre ciclos é definitivoF
        
            wait_us(100);

    }

// Função de controle automatico

    void Automatico() {

        // Caso seja identificado um numero dentro da serial, o mesmo é convertido para um valor numérico a ser guardado na variável "qtempo"

            if(atoi(Comandos) != 0) {

                qtempo = atoi(Comandos);

                // Limpeza da variável Comandos

                    Limpa();

            }

        // Se o tempo desejado seja negativo, é retirado o módulo do valor e guardado na variável "qtempo_abs"

            if (qtempo < 0) {

                qtempo_abs = -qtempo;

            }

        // Caso contrário, o valor da variável é colocado inteiramente na outra, sem alterações

            else {

                qtempo_abs = qtempo;

            }

        // Caso seja executado a rotina automática do motor

            if (strcmp(Comandos, "Executar") == 0) {

                // Habilitação dos braços da ponte H

                    EN_A.write(1);

                // Limpeza da variável Comandos

                    Limpa();

                // Quando o tempo estabelecido é negativo, o sentido definido é o antihorario

                    if (qtempo < 0) {

                        IN_A = 1;
                        IN_B = 0;

                    }

                // Quando o tempo estabelecido é negativo, o sentido definido é o horario

                    if (qtempo >= 0) {

                        IN_A = 0;
                        IN_B = 1;

                    }
                
                // Os comandos são executados pelo tempo definido pelo usuário
                
                    wait(qtempo_abs);

                // Zeramento da variável de todas as variáveis utilizadas para permitir novo comando                    
               
                    qtempo = 0;
                    qtempo_abs = 0;

                // Desligamento dos braços da ponte H
                
                    EN_A = 0;
                    IN_A = 0;
                    IN_B = 0;

            }

    }

// Função Principal

    int main() {

        // Atribuição da função Callback em caso de mudanças na Serial

            MotorCC.attach(&Callback1);

        // Definição da velocidade de trasnmissão e recebimento de dados na Serial 

            MotorCC.baud(115200);

        // Loop Principal

            while(1) {

                // Estado inicial das pontes H compo sendo desligadas

                    EN_A.write(0);
                    
                // Ativação do Modo Manual quando a palavra "Manual" seja recebida na Serial

                    if (strcmp(Comandos, "Manual") == 0) {

                        // Desligamento do Modo Automático e comutação do modo Manual

                            automatico = 0;
                            controle = !controle;

                        // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

                        Limpa();

                    }

                // Ativação do modo Automático quando a palavra "Automatica" seja recebida no Serial

                    if (strcmp(Comandos, "Automatico") == 0){

                        // Desligamento do Modo Manual e comutação do modo Automático

                            controle = 0;
                            automatico = !automatico;

                        // Limpeza da variável Comandos para possibilitar o recebimento de novos dados

                            Limpa();

                        // Desabilitação dos braços da ponte H

                            EN_A = 0;

                    }

                // Funcionamento do sistema em estado Manual

                    if (controle == 1) {

                        Manual();

                    }

                // Funcionamento do sistema em estado Automático

                    if (automatico == 1) {

                        Automatico();

                    }

            }

    }



